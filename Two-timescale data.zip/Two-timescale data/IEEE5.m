function [ data_b, data_g, data_l, data_r, data_s, data_f] = IEEE5()

baseMVA = 100;

%% bus data
%	bus_i	type	Pd	Qd	Gs	Bs	area	Vm	Va	baseKV	zone	Vmax	Vmin
data_b = [
	1	2	100	0	0	0	1	1	0	230	1	1.1	0.9;
	2	1	0	98.61	0	0	1	1	0	230	1	1.1	0.9;
	3	2	100	98.61	0	0	1	1	0	230	1	1.1	0.9;
	4	3	0	131.47	0	0	1	1	0	230	1	1.1	0.9;
	5	2	100	0	0	0	1	1	0	230	1	1.1	0.9;
];


%% branch data
%	fbus	tbus	r	x	b	rateA	rateB	rateC	ratio	angle	status	angmin	angmax
data_l = [
	1	2	0.00281	0.0281	0.00712	200	400	400	0	0	1	-360	360;
	1	4	0.00304	0.0304	0.00658	200	0	0	0	0	1	-360	360;
	1	5	0.00064	0.0064	0.03126	200	0	0	0	0	1	-360	360;
	2	3	0.00108	0.0108	0.01852	200	0	0	0	0	1	-360	360;
	3	4	0.00297	0.0297	0.00674	200	0	0	0	0	1	-360	360;
	4	5	0.00297	0.0297	0.00674	200	240	240	0	0	1	-360	360;
];


%% generator data
P_g_cap = 150;
%	bus	 Pmax	Pmin  Ramp  Cost 
data_g = [
	4	P_g_cap	 P_g_cap/3	  50    20 ;
];


%% renewable plant
% bus   capacity
data_r = [
 	2	100;
];


%% storage
% bus   eff   E  P  E_init��MW�� E_lower��MW��Terminal_upper Terminal_lower
EE = 100;
EE_init = EE/2;
data_s = [
	2	0.95  EE  EE/2  EE_init   EE/5   EE_init*1.1  EE_init*0.9
];

%% gas-fired
P_f_cap = 250;
% bus   Pmax Pmin Cost 
data_f = [
	5	P_f_cap	 P_f_cap/5  30;
];

end


